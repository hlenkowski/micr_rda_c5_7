# micr_rda_c5_7
project directory for homework assignment 5, focusing on data import and tidying
