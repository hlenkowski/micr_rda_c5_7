
#I am still having issues getting R to read my saved data files, so this does not actually run yet

library(tidyverse)

colloquium_assessment <- read_csv("r projects i think i did this right/notes/2_18_class/micr_rda_c5_7-main/data/colloquium_assessment.csv")
View(colloquium_assessment)

#read in differently? skip rows, (in textbook for how to do this)
#can add arguments after file mname in read.csv) 
#name header as the first row, then can skip up to whatever row when naming the data

update_assess <- colloquium_assessment |>
  pivot_longer(cols=c('Q4', 'Q5', 'Q6', 'Q7', 'Q8', 'Q9', 'Q10'),
               names_to = 'Question',
               values_to = 'score')
#need to make update assess where I remove the first four (five incl. header) rows since theyre characters
#Name the first row as the header, so it can be added back in after first 5 rows are deleted
#starting from beginning again, the name is now colloq_asses and assess_update:

header <- read_csv("r projects i think i did this right/notes/2_18_class/micr_rda_c5_7-main/data/colloquium_assessment.csv", n_max = 0)
View(header)

colloq_assess <- read_csv("r projects i think i did this right/notes/2_18_class/micr_rda_c5_7-main/data/colloquium_assessment.csv", skip = 5,col_names = header)
View(colloq_assess)

#what if I don't name the header
#back to original:
colloquium_assessment <- read_csv("r projects i think i did this right/notes/2_18_class/micr_rda_c5_7-main/data/colloquium_assessment.csv")
upd_colloquium <- colloquium_assessment[-c(1:5)]
View(upd_colloquium)
#this doesn't work because the rows I want deleted have values in them so R is still including them
  






#starting over again, filtering after reaching Question

 
library(tidyverse)

#Q1: read_csv 
colloquium_assessment <- read_csv("r projects i think i did this right/notes/2_18_class/micr_rda_c5_7-main/data/colloquium_assessment.csv")
View(colloquium_assessment)

#Q2.1: clean the table
update_assess <- colloquium_assessment |>
  pivot_longer(cols=c('Q4', 'Q5', 'Q6', 'Q7', 'Q8', 'Q9', 'Q10'),
               names_to = 'Question',
               values_to = 'score')
View(update_assess)

#Q2.2: clear any non numerical values so that everything in the Q column is <dblr>
clean_assess <- update_assess |>
  mutate(
    Question = parse_number(Question)
  ) |>
  filter(!is.na(Question))
View(clean_assess)


avg_score <- clean_assess |>
  summarize(avg_Q = mean(Question, na.rm = TRUE))




mean_val <- assessment %>%
  summarise(mean_col1 = mean(as.numeric(as.character(Column1)), na.rm = TRUE)) %>%
  pull(mean_col1)









   mutate(
    Question = parse_number(Question)
  )



avg_score <- update_assess |>
  group_by(Question) |>
  summarise(
    avg_total = mean(score, na.rm = TRUE)
  )

avg_score |>
  group_by(Question) |>
  filter(Question >= 7 & Question >= 14) |>
  summarise(
    avg_after_7 = mean(score, na.rm = TRUE)
  )

